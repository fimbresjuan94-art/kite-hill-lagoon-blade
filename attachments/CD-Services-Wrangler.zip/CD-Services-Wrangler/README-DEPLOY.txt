CD SERVICES — WRANGLER DEPLOY

This package keeps the website and Worker source files unchanged and puts
static files under public/ for Cloudflare Workers Static Assets. The Pages-only
_routes.json is intentionally not included; its Worker-first route behavior is
in wrangler.jsonc.

Included project layout:
  _worker.js                 Worker entry point
  wrangler.jsonc             Wrangler configuration
  public/index.html          Main website
  public/admin/index.html    Site editor
  public/img/                Website images
  public/_headers            Existing response headers

Deploy from this folder:
  1. Install Node.js if it is not already installed.
  2. Open a terminal in this folder.
  3. Run: npx wrangler login
  4. Run: npx wrangler deploy

The config uses the Worker name shown in the uploaded Cloudflare screenshot:
arch-sys-111. Review that name before deploying; Wrangler will deploy/update that
Worker name.

SITE_KV is configured for automatic provisioning on first deploy. If you
already have a SITE_KV namespace with saved site data, replace the kv_namespaces
entry with its existing ID before deploying to preserve that data.

keep_vars=true preserves existing dashboard variables such as
ACCESS_TEAM_DOMAIN and ACCESS_AUD. For a new Worker, add those variables and
finish Cloudflare Access setup before using /admin. Do not put secrets in this
file.
