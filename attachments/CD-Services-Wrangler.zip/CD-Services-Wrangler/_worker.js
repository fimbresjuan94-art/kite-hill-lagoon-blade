// CD Services LLC - site worker for Cloudflare Pages.
// Serves the public site, applies the owner's edits, and runs the private editor.
// Only the two addresses below can use the editor, and only after Cloudflare Access signs them in.

const ADMINS = ['jdurazo@cdigs.bid', 'jpfm@cdigs.bid'];

// What the page says out of the box. Edits replace these exact strings.
const DEFAULTS = {
  site: {
    phoneEn: '(480) 989-5802',
    phoneEs: '(623) 522-1923',
    email1: 'estimates.carranzadig@gmail.com',
    email2: 'cdsexcavation@gmail.com',
    email3: 'info@cdigs.bid',
    facebook: 'https://www.facebook.com/profile.php?id=100064277851753'
  },
  notice: { on: false, en: '', es: '' },
  gallery: { hidden: [], extra: [] }
};
const BUILTIN_PHOTOS = 10;
const MAX_EXTRA = 60;
const MAX_UPLOAD = 3 * 1024 * 1024;

const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: JSON_HEADERS });
const text = (msg, status = 200) => new Response(msg, { status, headers: { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' } });

export default {
  async fetch(request, env) {
    try {
      const url = new URL(request.url);
      const p = url.pathname;

      if (p.startsWith('/api/admin/')) return await adminApi(request, env, url);
      if (p.startsWith('/u/')) return await servePhoto(env, p.slice(3));
      if (p === '/' || p === '/index.html') return await home(request, env);
      if (p === '/admin' || p.startsWith('/admin/')) return await adminPage(request, env, url);

      return env.ASSETS.fetch(request);
    } catch (err) {
      return text('Something went wrong. Please try again in a moment.', 500);
    }
  }
};

/* ---------------------------------------------------------------- content */

async function getContent(env) {
  let saved = null;
  if (env.SITE_KV) {
    try { saved = await env.SITE_KV.get('content', 'json'); } catch (e) { saved = null; }
  }
  return mergeContent(saved);
}

function mergeContent(saved) {
  const c = JSON.parse(JSON.stringify(DEFAULTS));
  if (!saved || typeof saved !== 'object') return c;
  if (saved.site && typeof saved.site === 'object') {
    for (const k of Object.keys(c.site)) if (typeof saved.site[k] === 'string' && saved.site[k].trim()) c.site[k] = saved.site[k].trim();
  }
  if (saved.notice && typeof saved.notice === 'object') {
    c.notice.on = !!saved.notice.on;
    c.notice.en = typeof saved.notice.en === 'string' ? saved.notice.en : '';
    c.notice.es = typeof saved.notice.es === 'string' ? saved.notice.es : '';
  }
  if (saved.gallery && typeof saved.gallery === 'object') {
    if (Array.isArray(saved.gallery.hidden)) c.gallery.hidden = saved.gallery.hidden.filter(n => Number.isInteger(n) && n >= 1 && n <= BUILTIN_PHOTOS);
    if (Array.isArray(saved.gallery.extra)) {
      c.gallery.extra = saved.gallery.extra
        .filter(x => x && typeof x.id === 'string' && /^[a-f0-9]{16}$/.test(x.id))
        .map(x => ({ id: x.id, alt: String(x.alt || '').slice(0, 200), w: clampInt(x.w, 1, 6000, 1200), h: clampInt(x.h, 1, 6000, 900) }));
    }
  }
  return c;
}

function clampInt(v, lo, hi, fallback) {
  const n = parseInt(v, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(hi, Math.max(lo, n));
}

const escHtml = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
// Used for the Spanish copy, which the page reads back as HTML: escape twice so it stays plain text.
const escAttrOfHtml = s => escHtml(escHtml(s));

const digits = s => String(s).replace(/\D/g, '');
function phoneParts(display) {
  let d = digits(display);
  if (d.length === 11 && d[0] === '1') d = d.slice(1);
  if (d.length !== 10) return null;
  return { digits: d, display: `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`, dashed: `${d.slice(0, 3)}-${d.slice(3, 6)}-${d.slice(6)}` };
}

function render(html, c) {
  const swaps = [];
  const d = phoneParts(DEFAULTS.site.phoneEn), d2 = phoneParts(DEFAULTS.site.phoneEs);
  const n = phoneParts(c.site.phoneEn), n2 = phoneParts(c.site.phoneEs);
  if (n && d) swaps.push([d.dashed, n.dashed], [d.display, n.display], [d.digits, n.digits]);
  if (n2 && d2) swaps.push([d2.dashed, n2.dashed], [d2.display, n2.display], [d2.digits, n2.digits]);
  for (const k of ['email1', 'email2', 'email3', 'facebook']) {
    if (c.site[k] !== DEFAULTS.site[k]) swaps.push([DEFAULTS.site[k], c.site[k]]);
  }
  for (const [from, to] of swaps) html = html.split(from).join(to);

  // notice at the top of the intro
  let notice = '';
  const en = c.notice.en.trim(), es = c.notice.es.trim();
  if (c.notice.on && (en || es)) {
    const a = en || es, b = es || en;
    notice = `<p class="notice" role="status" data-es="${escAttrOfHtml(b)}">${escHtml(a)}</p>`;
  }
  html = html.replace('<!--NOTICE-->', notice);

  // photos
  const extra = c.gallery.extra.map(x =>
    `<img data-g="u" src="/u/${x.id}" alt="${escHtml(x.alt)}" width="${x.w}" height="${x.h}" loading="lazy" decoding="async">`).join('\n   ');
  html = html.replace('<!--GALLERY_EXTRA-->', extra);
  if (c.gallery.hidden.length) {
    const css = c.gallery.hidden.map(i => `.gal img[data-g="${i}"]`).join(',') + '{display:none!important}';
    html = html.replace('<!--HEAD_INJECT-->', `<style id="owner-hide">${css}</style>\n<!--HEAD_INJECT-->`);
  }
  return html;
}

async function home(request, env) {
  const res = await env.ASSETS.fetch(request);
  const type = res.headers.get('content-type') || '';
  if (!res.ok || !type.includes('text/html')) return res;
  const html = render(await res.text(), await getContent(env));
  return new Response(html, {
    status: 200,
    headers: {
      'content-type': 'text/html; charset=utf-8',
      'cache-control': 'public, max-age=0, must-revalidate',
      'x-content-type-options': 'nosniff',
      'x-frame-options': 'SAMEORIGIN',
      'referrer-policy': 'strict-origin-when-cross-origin'
    }
  });
}

/* ---------------------------------------------------------------- photos */

function sniff(bytes) {
  if (bytes.length > 12 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg';
  if (bytes.length > 12 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return 'image/png';
  if (bytes.length > 12 && bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 && bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50) return 'image/webp';
  return null;
}

async function servePhoto(env, name) {
  const id = name.replace(/\.(jpg|jpeg|png|webp)$/i, '');
  if (!/^[a-f0-9]{16}$/.test(id) || !env.SITE_KV) return text('Not found', 404);
  const { value, metadata } = await env.SITE_KV.getWithMetadata('img:' + id, { type: 'arrayBuffer' });
  if (!value) return text('Not found', 404);
  const type = metadata && ['image/jpeg', 'image/png', 'image/webp'].includes(metadata.type) ? metadata.type : 'image/jpeg';
  return new Response(value, {
    headers: {
      'content-type': type,
      'cache-control': 'public, max-age=31536000, immutable',
      'x-content-type-options': 'nosniff'
    }
  });
}

/* ---------------------------------------------------------------- sign-in check */

let jwksCache = { at: 0, keys: null, team: '' };

function b64urlToBytes(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
const b64urlToJson = s => JSON.parse(new TextDecoder().decode(b64urlToBytes(s)));

function teamHost(env) {
  return String(env.ACCESS_TEAM_DOMAIN || '').trim().replace(/^https?:\/\//i, '').replace(/\/.*$/, '').toLowerCase();
}

async function getKeys(team) {
  const now = Date.now();
  if (jwksCache.keys && jwksCache.team === team && now - jwksCache.at < 10 * 60 * 1000) return jwksCache.keys;
  const res = await fetch(`https://${team}/cdn-cgi/access/certs`);
  if (!res.ok) throw new Error('keys');
  const body = await res.json();
  jwksCache = { at: now, keys: body.keys || [], team };
  return jwksCache.keys;
}

// Returns the signed-in email, or a Response explaining why not.
async function whoIsThis(request, env) {
  const team = teamHost(env), aud = String(env.ACCESS_AUD || '').trim();
  if (!team || !aud) {
    return text('The editor sign-in is not finished being set up yet. Open the START HERE guide that came with the site and finish step 5.', 503);
  }
  const token = request.headers.get('Cf-Access-Jwt-Assertion');
  if (!token) return text('Please sign in. Open cdigs.bid/admin from your own computer or phone.', 401);
  try {
    const parts = token.split('.');
    if (parts.length !== 3) throw new Error('shape');
    const header = b64urlToJson(parts[0]);
    const payload = b64urlToJson(parts[1]);
    if (header.alg !== 'RS256') throw new Error('alg');
    const keys = await getKeys(team);
    const jwk = keys.find(k => k.kid === header.kid);
    if (!jwk) throw new Error('kid');
    const key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
    const ok = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, b64urlToBytes(parts[2]), new TextEncoder().encode(parts[0] + '.' + parts[1]));
    if (!ok) throw new Error('sig');
    const now = Math.floor(Date.now() / 1000);
    if (typeof payload.exp !== 'number' || payload.exp < now) throw new Error('exp');
    if (typeof payload.nbf === 'number' && payload.nbf > now + 60) throw new Error('nbf');
    if (payload.iss !== `https://${team}`) throw new Error('iss');
    const auds = Array.isArray(payload.aud) ? payload.aud : [payload.aud];
    if (!auds.includes(aud)) throw new Error('aud');
    const email = String(payload.email || '').toLowerCase();
    if (!ADMINS.includes(email)) return text('This address is not allowed to edit the site.', 403);
    return { email };
  } catch (e) {
    return text('Your sign-in could not be checked. Reload the page and sign in again.', 401);
  }
}

/* ---------------------------------------------------------------- editor */

async function adminPage(request, env, url) {
  const who = await whoIsThis(request, env);
  if (who instanceof Response) return who;
  const res = await env.ASSETS.fetch(new Request(url.origin + '/admin/', { headers: request.headers }));
  const headers = new Headers(res.headers);
  headers.set('cache-control', 'no-store');
  headers.set('x-robots-tag', 'noindex, nofollow');
  headers.set('x-frame-options', 'DENY');
  return new Response(res.body, { status: res.status, headers });
}

function sameOrigin(request, url) {
  const o = request.headers.get('origin');
  return !!o && o === url.origin;
}

function cleanText(v, max) {
  return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, max);
}

async function saveContent(env, c) {
  await env.SITE_KV.put('content', JSON.stringify(c));
}

async function adminApi(request, env, url) {
  const who = await whoIsThis(request, env);
  if (who instanceof Response) return who;
  const route = url.pathname.slice('/api/admin/'.length);
  const method = request.method;

  if (method !== 'GET' && !sameOrigin(request, url)) return json({ error: 'Blocked: request did not come from the editor page.' }, 403);

  if (route === 'me' && method === 'GET') {
    return json({ email: who.email, storage: !!env.SITE_KV, builtin: BUILTIN_PHOTOS });
  }
  if (!env.SITE_KV) return json({ error: 'Saving is not connected yet. Finish step 4 in the START HERE guide.' }, 503);

  if (route === 'content' && method === 'GET') return json(await getContent(env));

  if (route === 'content' && method === 'PUT') {
    let body;
    try { body = await request.json(); } catch (e) { return json({ error: 'Could not read that.' }, 400); }
    const current = await getContent(env);
    const next = JSON.parse(JSON.stringify(current));

    if (body.site && typeof body.site === 'object') {
      const s = body.site;
      const pe = phoneParts(cleanText(s.phoneEn, 30)), ps = phoneParts(cleanText(s.phoneEs, 30));
      if (!pe) return json({ error: 'The English phone number needs 10 digits.' }, 400);
      if (!ps) return json({ error: 'The Spanish phone number needs 10 digits.' }, 400);
      next.site.phoneEn = pe.display;
      next.site.phoneEs = ps.display;
      const emailRe = /^[^\s@<>"']+@[^\s@<>"']+\.[^\s@<>"']{2,}$/;
      for (const k of ['email1', 'email2', 'email3']) {
        const v = cleanText(s[k], 120).toLowerCase();
        if (!emailRe.test(v)) return json({ error: 'One of the email addresses does not look right.' }, 400);
        next.site[k] = v;
      }
      const fb = cleanText(s.facebook, 300);
      if (!/^https:\/\/[^\s"'<>]+$/.test(fb)) return json({ error: 'The Facebook link must start with https://' }, 400);
      next.site.facebook = fb;
    }

    if (body.notice && typeof body.notice === 'object') {
      next.notice.on = !!body.notice.on;
      next.notice.en = cleanText(body.notice.en, 240);
      next.notice.es = cleanText(body.notice.es, 240);
      if (next.notice.on && !next.notice.en && !next.notice.es) return json({ error: 'Type the notice text, or turn the notice off.' }, 400);
    }

    if (body.gallery && typeof body.gallery === 'object') {
      if (Array.isArray(body.gallery.hidden)) {
        next.gallery.hidden = [...new Set(body.gallery.hidden.map(Number).filter(n => Number.isInteger(n) && n >= 1 && n <= BUILTIN_PHOTOS))];
      }
      if (Array.isArray(body.gallery.extra)) {
        const byId = new Map(current.gallery.extra.map(x => [x.id, x]));
        const ordered = [];
        for (const item of body.gallery.extra) {
          const base = item && byId.get(item.id);
          if (!base) continue;
          ordered.push({ ...base, alt: cleanText(item.alt, 200) || base.alt });
          byId.delete(item.id);
        }
        next.gallery.extra = ordered;
        // anything not listed was removed: delete its file too
        for (const gone of byId.keys()) await env.SITE_KV.delete('img:' + gone);
      }
    }

    await saveContent(env, next);
    return json(next);
  }

  if (route === 'upload' && method === 'POST') {
    const current = await getContent(env);
    if (current.gallery.extra.length >= MAX_EXTRA) return json({ error: 'That is the most photos the page holds. Remove one first.' }, 400);
    const alt = cleanText(url.searchParams.get('alt'), 200);
    if (!alt) return json({ error: 'Describe the photo in a few words first. Screen readers read this out loud.' }, 400);
    const buf = await request.arrayBuffer();
    if (!buf.byteLength || buf.byteLength > MAX_UPLOAD) return json({ error: 'That photo is too large. Try a smaller one.' }, 400);
    const type = sniff(new Uint8Array(buf, 0, Math.min(16, buf.byteLength)));
    if (!type) return json({ error: 'Use a JPG, PNG or WebP photo.' }, 400);
    const idBytes = new Uint8Array(8);
    crypto.getRandomValues(idBytes);
    const id = [...idBytes].map(b => b.toString(16).padStart(2, '0')).join('');
    await env.SITE_KV.put('img:' + id, buf, { metadata: { type } });
    const item = { id, alt, w: clampInt(url.searchParams.get('w'), 1, 6000, 1200), h: clampInt(url.searchParams.get('h'), 1, 6000, 900) };
    current.gallery.extra.push(item);
    await saveContent(env, current);
    return json(item, 201);
  }

  return json({ error: 'Not found' }, 404);
}
