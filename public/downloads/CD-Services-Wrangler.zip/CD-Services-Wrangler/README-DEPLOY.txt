CD SERVICES — CLOUDFLARE UPLOAD

Same kind of package as the old Wrangler zip. This one has the public site
and El corral (owner, manager, developer, and crew).

What is in here
  brand/            the public page
  assets/           the yard
  _worker.js/       the app
  wrangler.jsonc    Cloudflare config
  _routes.json      which paths the app handles
  _headers          cache rules

Doors
  Public site       /
  El corral         /admin
  Truck             /field
  The little fence on the public page opens /admin.

Deploy
  1. Unzip this folder.
  2. Open a terminal in CD-Services-Wrangler.
  3. Run: npx wrangler login
  4. Run: npx wrangler pages deploy . --project-name=cd-services

Or in the Cloudflare dashboard: Workers & Pages, Create, upload the
contents of this folder.

Sign-in emails are not stored in this file. Passwords are not in this package.
